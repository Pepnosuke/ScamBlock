chrome.runtime.onInstalled.addListener(() => {
  console.log("Qwen Chatbot Extension installed!");
});
